package com.ever.north.customer.service.specification;

import com.ever.north.customer.service.dao.CustomerDAO;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class CustomerSpecification {

    public static Specification<CustomerDAO> getCustomerByCriteria(
            Long customerid,
            String firstname,
            String lastname,
            LocalDate dob,
            String streetAddress,
            String city,
            String state,
            String zip,
            String email,
            String phone) {

        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (customerid != null) {
                predicates.add(criteriaBuilder.equal(root.get("customerid"), customerid));
            }

            if (firstname != null && !firstname.isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("firstname"), firstname));
            }

            if (lastname != null && !lastname.isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("lastname"), lastname));
            }

            if (dob != null) {
                predicates.add(criteriaBuilder.equal(root.get("dob"), dob));
            }

            if (streetAddress != null && !streetAddress.isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("streetAddress"), streetAddress));
            }

            if (city != null && !city.isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("city"), city));
            }

            if (state != null && !state.isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("state"), state));
            }

            if (zip != null && !zip.isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("zip"), zip));
            }

            if (email != null && !email.isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("email"), email));
            }

            if (phone != null && !phone.isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("phone"), phone));
            }

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }
}