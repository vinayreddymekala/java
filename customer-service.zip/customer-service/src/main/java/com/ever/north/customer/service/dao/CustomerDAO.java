package com.ever.north.customer.service.dao;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;

@Entity
@Table(name = "customer")
@Data
public class CustomerDAO {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long customerid;

    private String firstname;
    private String lastname;
    private LocalDate dob;
    private String streetAddress;
    private String city;
    private String state;
    private String zip;
    private String email;
    private String phone;


}