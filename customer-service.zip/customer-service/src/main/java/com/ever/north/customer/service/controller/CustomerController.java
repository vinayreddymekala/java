package com.ever.north.customer.service.controller;

import com.ever.north.customer.service.dto.CustomerDTO;
import com.ever.north.customer.service.impl.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping("/{customerid}")
    public CustomerDTO getCustomerById(@PathVariable Long customerid) {
        return customerService.getCustomerById(customerid);
    }

    @GetMapping("/search")
    public List<CustomerDTO> searchCustomers(
            @RequestParam(required = false) Long customerid,
            @RequestParam(required = false) String firstname,
            @RequestParam(required = false) String lastname,
            @RequestParam(required = false) LocalDate dob,
            @RequestParam(required = false) String streetAddress,
            @RequestParam(required = false) String city,
            @RequestParam(required = false) String state,
            @RequestParam(required = false) String zip,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String phone) {

        return customerService.searchCustomers(customerid, firstname, lastname, dob, streetAddress, city, state, zip, email, phone);
    }
}
