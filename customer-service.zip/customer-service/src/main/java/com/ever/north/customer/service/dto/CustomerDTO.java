package com.ever.north.customer.service.dto;

import lombok.Data;

import java.time.LocalDate;
@Data
public class CustomerDTO {
    private Long customerid;

    private String firstname;
    private String lastname;
    private LocalDate dob;
    private String streetAddress;
    private String city;
    private String state;
    private String zip;
    private String email;
    private String phone;

}