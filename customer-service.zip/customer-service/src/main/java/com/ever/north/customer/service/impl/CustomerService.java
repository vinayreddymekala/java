package com.ever.north.customer.service.impl;

import com.ever.north.customer.service.dao.CustomerDAO;
import com.ever.north.customer.service.dto.CustomerDTO;
import com.ever.north.customer.service.repo.CustomerRepository;
import com.ever.north.customer.service.specification.CustomerSpecification;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class CustomerService {

    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Autowired
    private CustomerRepository customerRepository;

    public CustomerDTO getCustomerById(Long customerid) {
        log.info("Searching customers with customerId: {}",customerid);
        Optional<CustomerDAO> optionalCustomerDAO = customerRepository.findByCustomerid(customerid);
        if(optionalCustomerDAO.isPresent()){
            return toDTO(optionalCustomerDAO.get());
        }
        return new CustomerDTO();
    }

    public List<CustomerDTO> searchCustomers(Long customerid, String firstname, String lastname, LocalDate dob, String streetAddress, String city, String state, String zip, String email, String phone) {
        log.info("Searching customers with parameters customerId: {}, firstName: {}, lastName: {}, Dob: {}, streetAddress: {}, city: {}, state: {}, zip: {}, email: {}, phone: {}",
                customerid, firstname, lastname, dob, streetAddress, city, state, zip, email, phone);

        List<CustomerDTO> customerDTOS = new ArrayList<>();
        Specification<CustomerDAO> spec = CustomerSpecification.getCustomerByCriteria(customerid, firstname, lastname, dob, streetAddress, city, state, zip, email, phone);
        List<CustomerDAO> customerDAOS = customerRepository.findAll(spec);
        if(!CollectionUtils.isEmpty(customerDAOS)){
            customerDAOS.forEach(customerDAO -> {
                customerDTOS.add(toDTO(customerDAO));
            });
        }
        return customerDTOS;
    }



    public static CustomerDTO toDTO(CustomerDAO customerDAO) {
        if (customerDAO == null) {
            return null;
        }

        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setCustomerid(customerDAO.getCustomerid());
        customerDTO.setFirstname(customerDAO.getFirstname());
        customerDTO.setLastname(customerDAO.getLastname());
        customerDTO.setDob(customerDAO.getDob() != null ? LocalDate.parse(customerDAO.getDob().format(dateFormatter)) : null);
        customerDTO.setStreetAddress(customerDAO.getStreetAddress());
        customerDTO.setCity(customerDAO.getCity());
        customerDTO.setState(customerDAO.getState());
        customerDTO.setZip(customerDAO.getZip());
        customerDTO.setEmail(customerDAO.getEmail());
        customerDTO.setPhone(customerDAO.getPhone());

        return customerDTO;
    }
}