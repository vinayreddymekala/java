package com.ever.north.customer.service.repo;


import com.ever.north.customer.service.dao.CustomerDAO;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Optional;

public interface CustomerRepository extends JpaRepository<CustomerDAO, Long>, JpaSpecificationExecutor<CustomerDAO> {
    Optional<CustomerDAO> findByCustomerid(Long customerid);

    List<CustomerDAO> findAll(Specification<CustomerDAO> spec);
}