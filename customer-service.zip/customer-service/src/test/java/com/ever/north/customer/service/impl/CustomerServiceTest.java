package com.ever.north.customer.service.impl;

import com.ever.north.customer.service.dao.CustomerDAO;
import com.ever.north.customer.service.dto.CustomerDTO;
import com.ever.north.customer.service.repo.CustomerRepository;
import com.ever.north.customer.service.specification.CustomerSpecification;
import org.junit.jupiter.api.Test;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class CustomerServiceTest {
    @Test
    public void test_getCustomerById_returns_valid_CustomerDTO_when_customer_exists() {
        CustomerRepository customerRepository = mock(CustomerRepository.class);
        CustomerService customerService = new CustomerService();
        ReflectionTestUtils.setField(customerService, "customerRepository", customerRepository);

        CustomerDAO customerDAO = new CustomerDAO();
        customerDAO.setCustomerid(1L);
        customerDAO.setFirstname("John");
        customerDAO.setLastname("Doe");
        customerDAO.setDob(LocalDate.of(1990, 1, 1));
        customerDAO.setStreetAddress("123 Main St");
        customerDAO.setCity("Anytown");
        customerDAO.setState("CA");
        customerDAO.setZip("12345");
        customerDAO.setEmail("john.doe@example.com");
        customerDAO.setPhone("555-1234");

        when(customerRepository.findByCustomerid(1L)).thenReturn(Optional.of(customerDAO));

        CustomerDTO result = customerService.getCustomerById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getCustomerid().longValue());
        assertEquals("John", result.getFirstname());
        assertEquals("Doe", result.getLastname());
        assertEquals(LocalDate.of(1990, 1, 1), result.getDob());
        assertEquals("123 Main St", result.getStreetAddress());
        assertEquals("Anytown", result.getCity());
        assertEquals("CA", result.getState());
        assertEquals("12345", result.getZip());
        assertEquals("john.doe@example.com", result.getEmail());
        assertEquals("555-1234", result.getPhone());
    }

    @Test
    public void test_getCustomerById_handles_null_customerid_gracefully() {
        CustomerRepository customerRepository = mock(CustomerRepository.class);
        CustomerService customerService = new CustomerService();
        ReflectionTestUtils.setField(customerService, "customerRepository", customerRepository);

        CustomerDTO result = customerService.getCustomerById(null);

        assertNotNull(result);
        assertNull(result.getCustomerid());
        assertNull(result.getFirstname());
        assertNull(result.getLastname());
        assertNull(result.getDob());
        assertNull(result.getStreetAddress());
        assertNull(result.getCity());
        assertNull(result.getState());
        assertNull(result.getZip());
        assertNull(result.getEmail());
        assertNull(result.getPhone());
    }

    @Test
    public void test_getCustomerById_returns_empty_CustomerDTO_when_customer_does_not_exist() {
        CustomerRepository customerRepository = mock(CustomerRepository.class);
        CustomerService customerService = new CustomerService();
        ReflectionTestUtils.setField(customerService, "customerRepository", customerRepository);

        when(customerRepository.findByCustomerid(1L)).thenReturn(Optional.empty());

        CustomerDTO result = customerService.getCustomerById(1L);

        assertNotNull(result);
        assertNull(result.getCustomerid());
        assertNull(result.getFirstname());
        assertNull(result.getLastname());
        assertNull(result.getDob());
        assertNull(result.getStreetAddress());
        assertNull(result.getCity());
        assertNull(result.getState());
        assertNull(result.getZip());
        assertNull(result.getEmail());
        assertNull(result.getPhone());
    }


    @Test
    public void test_searchCustomers_returns_list_of_CustomerDTOs_matching_search_criteria() {
        CustomerRepository customerRepository = mock(CustomerRepository.class);
        CustomerService customerService = new CustomerService();
        ReflectionTestUtils.setField(customerService, "customerRepository", customerRepository);

        List<CustomerDAO> customerDAOS = new ArrayList<>();
        CustomerDAO customerDAO = new CustomerDAO();
        customerDAO.setCustomerid(1L);
        customerDAO.setFirstname("Vinay");
        customerDAO.setLastname("Mekala");
        customerDAO.setDob(LocalDate.parse("1991-03-26"));
        customerDAO.setStreetAddress("Kukatpally");
        customerDAO.setCity("Hyderabad");
        customerDAO.setState("TG");
        customerDAO.setZip("500085");
        customerDAO.setEmail("mekalavinayreddy@gmail.com");
        customerDAO.setPhone("9177456120");
        customerDAOS.add(customerDAO);

        Specification<CustomerDAO> spec = CustomerSpecification.getCustomerByCriteria(1L, "Vinay", "Mekala", LocalDate.parse("1991-03-26"), "Kukatpally", "Hyderabad", "TG", "500085", "mekalavinayreddy@gmail.com", "9177456120");
        when(customerRepository.findAll(spec)).thenReturn(customerDAOS);

        List<CustomerDTO> result = customerService.searchCustomers(1L, "Vinay", "Mekala", LocalDate.parse("1991-03-26"), "Kukatpally", "Hyderabad", "TG", "500085", "mekalavinayreddy@gmail.com", "9177456120");

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getCustomerid().longValue());
        assertEquals("Vinay", result.get(0).getFirstname());
        assertEquals("Mekala", result.get(0).getLastname());
        assertEquals(LocalDate.of(1991, 03, 26), result.get(0).getDob());
        assertEquals("Kukatpally", result.get(0).getStreetAddress());
        assertEquals("Hyderabad", result.get(0).getCity());
        assertEquals("TG", result.get(0).getState());
        assertEquals("500085", result.get(0).getZip());
        assertEquals("mekalavinayreddy@gmail.com", result.get(0).getEmail());
        assertEquals("9177456120", result.get(0).getPhone());
    }

    @Test
    public void test_searchCustomers_returns_empty_list_when_no_customers_match_search_criteria() {
        CustomerRepository customerRepository = mock(CustomerRepository.class);
        CustomerService customerService = new CustomerService();
        ReflectionTestUtils.setField(customerService, "customerRepository", customerRepository);

        Specification<CustomerDAO> spec = CustomerSpecification.getCustomerByCriteria(2L, "Jane", "Smith", LocalDate.of(1995, 5, 5), "456 Oak St", "Othertown", "NY", "54321", "jane.smith@example.com", "555-5678");
        when(customerRepository.findAll(spec)).thenReturn(Collections.emptyList());

        List<CustomerDTO> result = customerService.searchCustomers(2L, "Jane", "Smith", LocalDate.of(1995, 5, 5), "456 Oak St", "Othertown", "NY", "54321", "jane.smith@example.com", "555-5678");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}